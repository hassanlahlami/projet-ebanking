import { Component, OnInit } from '@angular/core';

import {NgClass, NgForOf, NgIf} from '@angular/common';
import {TranslatePipe} from '@ngx-translate/core';
import {CompteService} from '../../Service/CompteService';
import {VirementService} from '../../Service/VirementService';
import {CompteResDTO} from '../../model/dto/CompteResDTO';
import {VirementResDTO} from '../../model/dto/VirementResDTO';
import {CEpargneResDTO} from '../../model/dto/CEpargneResDTO';
import {FormsModule} from '@angular/forms';
import {RechargeResDTO} from '../../model/dto/RechargeResDTO';
import {InvoiceResDTO} from '../../model/dto/InvoiceResDTO';


@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  imports: [
    NgIf,
    NgForOf,
    NgClass,
    TranslatePipe,
    FormsModule
  ],
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {
  selectedOperation: string = 'virement';
  accounts: CompteResDTO[] = [];
  virements: VirementResDTO[] = []; // all virements
  recharges: RechargeResDTO[] = [];
  factures: InvoiceResDTO[] = [];
  selectedAccount: CompteResDTO | null = null;
  page=1;
  maxItems=3;
  totalPages: number = 1;
  constructor(private compteService: CompteService,private virementService:VirementService) {
  }

  ngOnInit() {


    this.compteService.getByClientId("1","compte","tout").subscribe((comptes: CompteResDTO[]) => {
      this.accounts.push(...comptes); // spread to add individual elements
      // Select the first account only after data is loaded
      if (!this.selectedAccount && this.accounts.length > 0) {
        const courantAccount = this.accounts.find(acc => acc.accountType === "CCourant");
        this.selectAccount(courantAccount || this.accounts[0]);
      }
      if(this.selectedAccount!=null){
        let accountId=this.selectedAccount.id;
        console.log(accountId);
        this.virementService.getVirementsByCompteId(accountId,this.page,this.maxItems).subscribe((virements: VirementResDTO[]) => {
          this.virements.push(...virements);
        });
      }
    });


    console.log(this.virements);


    console.log(this.accounts);
  }
  onOperationTypeChange() {
    if (!this.selectedAccount) return;

    switch (this.selectedOperation) {
      case 'virement':
        this.loadVirements();

        break;
      case 'recharge':
        console.log('Recharge sélectionnée pour le compte :', this.selectedAccount.rib);
        // Appel futur vers service de recharges
        break;
      case 'facture':
        console.log('Facture sélectionnée pour le compte :', this.selectedAccount.rib);
        // Appel futur vers service de factures
        break;
    }
  }
  selectOperation(type: string) {
    this.selectedOperation = type;
    this.onOperationTypeChange();
  }

  getAccountsByStatus(status: string): CompteResDTO[] {
    return this.accounts.filter(a => a.status === status);
  }
  loadVirements() {
    if (this.selectedAccount) {
      this.virements = [];
      this.virementService.getVirementsByCompteId(this.selectedAccount.id, this.page, this.maxItems)
        .subscribe(response => {
          this.virements = response.content;
          this.totalPages = response.totalPages;
        });
    }
  }
  setPage(p: number) {
    if (p < 1 || p > this.totalPages) return;
    this.page = p;
    this.loadVirements(); // recharge les virements de la nouvelle page
  }
  selectAccount(account: CompteResDTO) {
    this.selectedAccount = account;
    this.loadVirements();
  }
  getVisibleStatuses(): string[] {
    return ['ACTIF', 'BLOQUE', 'FERME'].filter(
      status => this.getAccountsByStatus(status).length > 0
    );
  }

}

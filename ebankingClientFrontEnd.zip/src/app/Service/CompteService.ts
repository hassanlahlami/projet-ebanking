import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {CompteResDTO} from '../model/dto/CompteResDTO';
import {CEpargneResDTO} from '../model/dto/CEpargneResDTO';
import {CCourantResDTO} from '../model/dto/CCouurantResDTO';


@Injectable({
  providedIn: 'root'
})
export class CompteService {
  private readonly apiUrl = 'http://localhost:8080/e_banking_2_war_exploded/api/comptes'; // adapte si nécessaire

  constructor(private http: HttpClient) {}

  /** Obtenir tous les comptes selon le type et le statut */
  getAll(type: string, status: string): Observable<any[]> {
    return this.http.get<any>(`${this.apiUrl}/${status}/${type}`);
  }

  /** Obtenir un compte par son ID */
  getById(id: string): Observable<CompteResDTO> {
    return this.http.get<CompteResDTO>(`${this.apiUrl}/compte/${id}`);
  }

  /** Obtenir tous les comptes d’un client */
  getByClientId(clientId: string, type: string, status: string): Observable<CompteResDTO[]> {

    return this.http.get<CompteResDTO[]>(`${this.apiUrl}/client/${clientId}/${type}/${status}`);
  }

  /** Créer un compte courant */
  createCourant(dto: Partial<CCourantResDTO>): Observable<CCourantResDTO> {
    return this.http.post<CCourantResDTO>(`${this.apiUrl}/comptecourant`, dto);
  }

  /** Créer un compte épargne */
  createEpargne(dto: Partial<CEpargneResDTO>): Observable<CEpargneResDTO> {
    return this.http.post<CEpargneResDTO>(`${this.apiUrl}/compteepargne`, dto);
  }

  /** Supprimer un compte par son ID */
  deleteById(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/compte/${id}`);
  }

  /** Changer le statut d’un compte */
  updateStatus(id: string, status: string): Observable<CompteResDTO> {
    const params = new HttpParams().set('status', status);
    return this.http.patch<CompteResDTO>(`${this.apiUrl}/compte/status/${id}`, null, { params });
  }
}

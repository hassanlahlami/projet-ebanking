import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {map, Observable} from 'rxjs';
import {VirementResDTO} from '../model/dto/VirementResDTO';

@Injectable({
  providedIn: 'root'
})
export class VirementService {
  private readonly apiUrl = 'http://localhost:8080/e_banking_2_war_exploded/api/virements'; // adapte si nécessaire

  constructor(private http: HttpClient) {

  }
  getVirementsByCompteId(id: Number, page: number, size: number): Observable<any> {
    let offset = page - 1;
    const params = new HttpParams()
      .set('size', size.toString())
      .set('offset', offset.toString()); // utilisez `page` si backend attend `page`

    return this.http.get<any>(`${this.apiUrl}/${id}`, { params });
  }

}
